/*    */ package net.mcreator.warlorb.item;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import net.mcreator.warlorb.ElementsWarlOrb;
/*    */ import net.mcreator.warlorb.ElementsWarlOrb.ModElement.Tag;
/*    */ import net.mcreator.warlorb.creativetab.TabWarlord;
/*    */ import net.mcreator.warlorb.procedure.ProcedureDustEmblemItemInHandTick;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.client.renderer.block.model.ModelResourceLocation;
/*    */ import net.minecraft.client.util.ITooltipFlag;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.client.event.ModelRegistryEvent;
/*    */ import net.minecraftforge.client.model.ModelLoader;
/*    */ import net.minecraftforge.fml.common.registry.GameRegistry.ObjectHolder;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ @Tag
/*    */ public class ItemDustEmblem
/*    */   extends ElementsWarlOrb.ModElement
/*    */ {
/*    */   @ObjectHolder("warlorb:dustemblem")
/* 28 */   public static final Item block = null;
/*    */   public ItemDustEmblem(ElementsWarlOrb instance) {
/* 30 */     super(instance, 19);
/*    */   }
/*    */ 
/*    */   
/*    */   public void initElements() {
/* 35 */     this.elements.items.add(() -> new ItemCustom());
/*    */   }
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void registerModels(ModelRegistryEvent event) {
/* 41 */     ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("warlorb:dustemblem", "inventory"));
/*    */   }
/*    */   
/*    */   public static class ItemCustom extends Item { public ItemCustom() {
/* 45 */       func_77656_e(0);
/* 46 */       this.field_77777_bU = 64;
/* 47 */       func_77655_b("dustemblem");
/* 48 */       setRegistryName("dustemblem");
/* 49 */       func_77637_a(TabWarlord.tab);
/*    */     }
/*    */ 
/*    */     
/*    */     public int func_77619_b() {
/* 54 */       return 0;
/*    */     }
/*    */ 
/*    */     
/*    */     public int func_77626_a(ItemStack itemstack) {
/* 59 */       return 0;
/*    */     }
/*    */ 
/*    */     
/*    */     public float func_150893_a(ItemStack par1ItemStack, IBlockState par2Block) {
/* 64 */       return 1.0F;
/*    */     }
/*    */ 
/*    */     
/*    */     public void func_77624_a(ItemStack itemstack, World world, List<String> list, ITooltipFlag flag) {
/* 69 */       super.func_77624_a(itemstack, world, list, flag);
/* 70 */       list.add("Like a rock in a sling");
/*    */     }
/*    */ 
/*    */     
/*    */     public void func_77663_a(ItemStack itemstack, World world, Entity entity, int slot, boolean par5) {
/* 75 */       super.func_77663_a(itemstack, world, entity, slot, par5);
/* 76 */       int x = (int)entity.field_70165_t;
/* 77 */       int y = (int)entity.field_70163_u;
/* 78 */       int z = (int)entity.field_70161_v;
/* 79 */       if (entity instanceof EntityLivingBase && ((EntityLivingBase)entity).func_184614_ca().equals(itemstack)) {
/* 80 */         HashMap<String, Object> $_dependencies = new HashMap<>();
/* 81 */         $_dependencies.put("entity", entity);
/* 82 */         ProcedureDustEmblemItemInHandTick.executeProcedure($_dependencies);
/*    */       } 
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\Jay.DESKTOP-FPHD60C\AppData\Roaming\.minecraft\mods\Warlord.jar!\net\mcreator\warlorb\item\ItemDustEmblem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */