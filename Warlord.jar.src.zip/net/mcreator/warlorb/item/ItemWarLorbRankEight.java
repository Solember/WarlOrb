/*     */ package net.mcreator.warlorb.item;
/*     */ 
/*     */ import com.google.common.collect.Multimap;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import net.mcreator.warlorb.ElementsWarlOrb;
/*     */ import net.mcreator.warlorb.ElementsWarlOrb.ModElement.Tag;
/*     */ import net.mcreator.warlorb.creativetab.TabWarlord;
/*     */ import net.mcreator.warlorb.procedure.ProcedureWarLorbRankEightRightClickedOnBlock;
/*     */ import net.mcreator.warlorb.procedure.ProcedureWarlOrbRankSevenItemInHandTick;
/*     */ import net.mcreator.warlorb.procedure.ProcedureWarlOrbRankSixItemInInventoryTick;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.renderer.block.model.ModelResourceLocation;
/*     */ import net.minecraft.client.util.ITooltipFlag;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.EntityEquipmentSlot;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.EnumActionResult;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.event.ModelRegistryEvent;
/*     */ import net.minecraftforge.client.model.ModelLoader;
/*     */ import net.minecraftforge.fml.common.registry.GameRegistry.ObjectHolder;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ @Tag
/*     */ public class ItemWarLorbRankEight
/*     */   extends ElementsWarlOrb.ModElement
/*     */ {
/*     */   @ObjectHolder("warlorb:warlorbrankeight")
/*  40 */   public static final Item block = null;
/*     */   public ItemWarLorbRankEight(ElementsWarlOrb instance) {
/*  42 */     super(instance, 12);
/*     */   }
/*     */ 
/*     */   
/*     */   public void initElements() {
/*  47 */     this.elements.items.add(() -> new ItemCustom());
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerModels(ModelRegistryEvent event) {
/*  53 */     ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("warlorb:warlorbrankeight", "inventory"));
/*     */   }
/*     */   
/*     */   public static class ItemCustom extends Item { public ItemCustom() {
/*  57 */       func_77656_e(0);
/*  58 */       this.field_77777_bU = 1;
/*  59 */       func_77655_b("warlorbrankeight");
/*  60 */       setRegistryName("warlorbrankeight");
/*  61 */       func_77637_a(TabWarlord.tab);
/*     */     }
/*     */ 
/*     */     
/*     */     public int func_77619_b() {
/*  66 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public int func_77626_a(ItemStack itemstack) {
/*  71 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public float func_150893_a(ItemStack par1ItemStack, IBlockState par2Block) {
/*  76 */       return 1.0F;
/*     */     }
/*     */ 
/*     */     
/*     */     public Multimap<String, AttributeModifier> func_111205_h(EntityEquipmentSlot slot) {
/*  81 */       Multimap<String, AttributeModifier> multimap = super.func_111205_h(slot);
/*  82 */       if (slot == EntityEquipmentSlot.MAINHAND) {
/*  83 */         multimap.put(SharedMonsterAttributes.field_111264_e.func_111108_a(), new AttributeModifier(field_111210_e, "Item modifier", 4.0D, 0));
/*     */         
/*  85 */         multimap.put(SharedMonsterAttributes.field_188790_f.func_111108_a(), new AttributeModifier(field_185050_h, "Item modifier", -2.4D, 0));
/*     */       } 
/*  87 */       return multimap;
/*     */     }
/*     */ 
/*     */     
/*     */     @SideOnly(Side.CLIENT)
/*     */     public boolean func_77636_d(ItemStack itemstack) {
/*  93 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void func_77624_a(ItemStack itemstack, World world, List<String> list, ITooltipFlag flag) {
/*  98 */       super.func_77624_a(itemstack, world, list, flag);
/*  99 */       list.add("When I point it at the ground I feel it push me up!");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public EnumActionResult onItemUseFirst(EntityPlayer entity, World world, BlockPos pos, EnumFacing direction, float hitX, float hitY, float hitZ, EnumHand hand) {
/* 105 */       EnumActionResult retval = super.onItemUseFirst(entity, world, pos, direction, hitX, hitY, hitZ, hand);
/* 106 */       ItemStack itemstack = entity.func_184586_b(hand);
/* 107 */       int x = pos.func_177958_n();
/* 108 */       int y = pos.func_177956_o();
/* 109 */       int z = pos.func_177952_p();
/*     */       
/* 111 */       HashMap<String, Object> $_dependencies = new HashMap<>();
/* 112 */       $_dependencies.put("entity", entity);
/* 113 */       ProcedureWarLorbRankEightRightClickedOnBlock.executeProcedure($_dependencies);
/*     */       
/* 115 */       return retval;
/*     */     }
/*     */ 
/*     */     
/*     */     public void func_77663_a(ItemStack itemstack, World world, Entity entity, int slot, boolean par5) {
/* 120 */       super.func_77663_a(itemstack, world, entity, slot, par5);
/* 121 */       int x = (int)entity.field_70165_t;
/* 122 */       int y = (int)entity.field_70163_u;
/* 123 */       int z = (int)entity.field_70161_v;
/* 124 */       if (entity instanceof EntityLivingBase && ((EntityLivingBase)entity).func_184614_ca().equals(itemstack)) {
/* 125 */         HashMap<String, Object> hashMap = new HashMap<>();
/* 126 */         hashMap.put("entity", entity);
/* 127 */         ProcedureWarlOrbRankSevenItemInHandTick.executeProcedure(hashMap);
/*     */       } 
/*     */       
/* 130 */       HashMap<String, Object> $_dependencies = new HashMap<>();
/* 131 */       $_dependencies.put("entity", entity);
/* 132 */       ProcedureWarlOrbRankSixItemInInventoryTick.executeProcedure($_dependencies);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\Jay.DESKTOP-FPHD60C\AppData\Roaming\.minecraft\mods\Warlord.jar!\net\mcreator\warlorb\item\ItemWarLorbRankEight.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */