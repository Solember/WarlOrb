/*     */ package net.mcreator.warlorb.item;
/*     */ 
/*     */ import com.google.common.collect.Multimap;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import net.mcreator.warlorb.ElementsWarlOrb;
/*     */ import net.mcreator.warlorb.ElementsWarlOrb.ModElement.Tag;
/*     */ import net.mcreator.warlorb.creativetab.TabWarlord;
/*     */ import net.mcreator.warlorb.procedure.ProcedureWarlOrbRankTwoItemInInventoryTick;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.renderer.block.model.ModelResourceLocation;
/*     */ import net.minecraft.client.util.ITooltipFlag;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.inventory.EntityEquipmentSlot;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.event.ModelRegistryEvent;
/*     */ import net.minecraftforge.client.model.ModelLoader;
/*     */ import net.minecraftforge.fml.common.registry.GameRegistry.ObjectHolder;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ @Tag
/*     */ public class ItemWarlOrbRankTwo
/*     */   extends ElementsWarlOrb.ModElement
/*     */ {
/*     */   @ObjectHolder("warlorb:warlorbranktwo")
/*  32 */   public static final Item block = null;
/*     */   public ItemWarlOrbRankTwo(ElementsWarlOrb instance) {
/*  34 */     super(instance, 3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void initElements() {
/*  39 */     this.elements.items.add(() -> new ItemCustom());
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerModels(ModelRegistryEvent event) {
/*  45 */     ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("warlorb:warlorbranktwo", "inventory"));
/*     */   }
/*     */   
/*     */   public static class ItemCustom extends Item { public ItemCustom() {
/*  49 */       func_77656_e(0);
/*  50 */       this.field_77777_bU = 1;
/*  51 */       func_77655_b("warlorbranktwo");
/*  52 */       setRegistryName("warlorbranktwo");
/*  53 */       func_77637_a(TabWarlord.tab);
/*     */     }
/*     */ 
/*     */     
/*     */     public int func_77619_b() {
/*  58 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public int func_77626_a(ItemStack itemstack) {
/*  63 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public float func_150893_a(ItemStack par1ItemStack, IBlockState par2Block) {
/*  68 */       return 1.0F;
/*     */     }
/*     */ 
/*     */     
/*     */     public Multimap<String, AttributeModifier> func_111205_h(EntityEquipmentSlot slot) {
/*  73 */       Multimap<String, AttributeModifier> multimap = super.func_111205_h(slot);
/*  74 */       if (slot == EntityEquipmentSlot.MAINHAND) {
/*  75 */         multimap.put(SharedMonsterAttributes.field_111264_e.func_111108_a(), new AttributeModifier(field_111210_e, "Item modifier", -2.0D, 0));
/*     */         
/*  77 */         multimap.put(SharedMonsterAttributes.field_188790_f.func_111108_a(), new AttributeModifier(field_185050_h, "Item modifier", -2.4D, 0));
/*     */       } 
/*  79 */       return multimap;
/*     */     }
/*     */ 
/*     */     
/*     */     @SideOnly(Side.CLIENT)
/*     */     public boolean func_77636_d(ItemStack itemstack) {
/*  85 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void func_77624_a(ItemStack itemstack, World world, List<String> list, ITooltipFlag flag) {
/*  90 */       super.func_77624_a(itemstack, world, list, flag);
/*  91 */       list.add("I hope I don't need these badges later.");
/*     */     }
/*     */ 
/*     */     
/*     */     public void func_77663_a(ItemStack itemstack, World world, Entity entity, int slot, boolean par5) {
/*  96 */       super.func_77663_a(itemstack, world, entity, slot, par5);
/*  97 */       int x = (int)entity.field_70165_t;
/*  98 */       int y = (int)entity.field_70163_u;
/*  99 */       int z = (int)entity.field_70161_v;
/*     */       
/* 101 */       HashMap<String, Object> $_dependencies = new HashMap<>();
/* 102 */       $_dependencies.put("entity", entity);
/* 103 */       ProcedureWarlOrbRankTwoItemInInventoryTick.executeProcedure($_dependencies);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\Jay.DESKTOP-FPHD60C\AppData\Roaming\.minecraft\mods\Warlord.jar!\net\mcreator\warlorb\item\ItemWarlOrbRankTwo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */