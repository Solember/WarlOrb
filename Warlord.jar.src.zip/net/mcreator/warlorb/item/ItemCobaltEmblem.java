/*    */ package net.mcreator.warlorb.item;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import net.mcreator.warlorb.ElementsWarlOrb;
/*    */ import net.mcreator.warlorb.ElementsWarlOrb.ModElement.Tag;
/*    */ import net.mcreator.warlorb.creativetab.TabWarlord;
/*    */ import net.mcreator.warlorb.procedure.ProcedureCobaltEmblemItemInInventoryTick;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.client.renderer.block.model.ModelResourceLocation;
/*    */ import net.minecraft.client.util.ITooltipFlag;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.client.event.ModelRegistryEvent;
/*    */ import net.minecraftforge.client.model.ModelLoader;
/*    */ import net.minecraftforge.fml.common.registry.GameRegistry.ObjectHolder;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ @Tag
/*    */ public class ItemCobaltEmblem
/*    */   extends ElementsWarlOrb.ModElement
/*    */ {
/*    */   @ObjectHolder("warlorb:cobaltemblem")
/* 27 */   public static final Item block = null;
/*    */   public ItemCobaltEmblem(ElementsWarlOrb instance) {
/* 29 */     super(instance, 14);
/*    */   }
/*    */ 
/*    */   
/*    */   public void initElements() {
/* 34 */     this.elements.items.add(() -> new ItemCustom());
/*    */   }
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void registerModels(ModelRegistryEvent event) {
/* 40 */     ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("warlorb:cobaltemblem", "inventory"));
/*    */   }
/*    */   
/*    */   public static class ItemCustom extends Item { public ItemCustom() {
/* 44 */       func_77656_e(0);
/* 45 */       this.field_77777_bU = 64;
/* 46 */       func_77655_b("cobaltemblem");
/* 47 */       setRegistryName("cobaltemblem");
/* 48 */       func_77637_a(TabWarlord.tab);
/*    */     }
/*    */ 
/*    */     
/*    */     public int func_77619_b() {
/* 53 */       return 0;
/*    */     }
/*    */ 
/*    */     
/*    */     public int func_77626_a(ItemStack itemstack) {
/* 58 */       return 0;
/*    */     }
/*    */ 
/*    */     
/*    */     public float func_150893_a(ItemStack par1ItemStack, IBlockState par2Block) {
/* 63 */       return 1.0F;
/*    */     }
/*    */ 
/*    */     
/*    */     public void func_77624_a(ItemStack itemstack, World world, List<String> list, ITooltipFlag flag) {
/* 68 */       super.func_77624_a(itemstack, world, list, flag);
/* 69 */       list.add("Speed of the hunter");
/*    */     }
/*    */ 
/*    */     
/*    */     public void func_77663_a(ItemStack itemstack, World world, Entity entity, int slot, boolean par5) {
/* 74 */       super.func_77663_a(itemstack, world, entity, slot, par5);
/* 75 */       int x = (int)entity.field_70165_t;
/* 76 */       int y = (int)entity.field_70163_u;
/* 77 */       int z = (int)entity.field_70161_v;
/*    */       
/* 79 */       HashMap<String, Object> $_dependencies = new HashMap<>();
/* 80 */       $_dependencies.put("entity", entity);
/* 81 */       ProcedureCobaltEmblemItemInInventoryTick.executeProcedure($_dependencies);
/*    */     } }
/*    */ 
/*    */ }


/* Location:              C:\Users\Jay.DESKTOP-FPHD60C\AppData\Roaming\.minecraft\mods\Warlord.jar!\net\mcreator\warlorb\item\ItemCobaltEmblem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */