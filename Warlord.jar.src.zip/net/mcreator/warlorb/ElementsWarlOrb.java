/*     */ package net.mcreator.warlorb;
/*     */ 
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import java.util.function.Supplier;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.SoundEvent;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.biome.Biome;
/*     */ import net.minecraft.world.chunk.IChunkProvider;
/*     */ import net.minecraft.world.gen.IChunkGenerator;
/*     */ import net.minecraft.world.storage.WorldSavedData;
/*     */ import net.minecraftforge.client.event.ModelRegistryEvent;
/*     */ import net.minecraftforge.event.RegistryEvent;
/*     */ import net.minecraftforge.fml.common.IFuelHandler;
/*     */ import net.minecraftforge.fml.common.IWorldGenerator;
/*     */ import net.minecraftforge.fml.common.discovery.ASMDataTable;
/*     */ import net.minecraftforge.fml.common.event.FMLInitializationEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.PlayerEvent;
/*     */ import net.minecraftforge.fml.common.network.IGuiHandler;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
/*     */ import net.minecraftforge.fml.common.registry.EntityEntry;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElementsWarlOrb
/*     */   implements IFuelHandler, IWorldGenerator
/*     */ {
/*  49 */   public final List<ModElement> elements = new ArrayList<>();
/*  50 */   public final List<Supplier<Block>> blocks = new ArrayList<>();
/*  51 */   public final List<Supplier<Item>> items = new ArrayList<>();
/*  52 */   public final List<Supplier<Biome>> biomes = new ArrayList<>();
/*  53 */   public final List<Supplier<EntityEntry>> entities = new ArrayList<>();
/*  54 */   public final List<Supplier<Potion>> potions = new ArrayList<>();
/*  55 */   public static Map<ResourceLocation, SoundEvent> sounds = new HashMap<>();
/*     */   
/*     */   private int messageID;
/*     */   
/*     */   public void preInit(FMLPreInitializationEvent event) {
/*     */     try {
/*  61 */       for (ASMDataTable.ASMData asmData : event.getAsmData().getAll(ModElement.Tag.class.getName())) {
/*  62 */         Class<?> clazz = Class.forName(asmData.getClassName());
/*  63 */         if (clazz.getSuperclass() == ModElement.class)
/*  64 */           this.elements.add(clazz.getConstructor(new Class[] { getClass() }).newInstance(new Object[] { this })); 
/*     */       } 
/*  66 */     } catch (Exception e) {
/*  67 */       e.printStackTrace();
/*     */     } 
/*  69 */     Collections.sort(this.elements);
/*  70 */     this.elements.forEach(ModElement::initElements);
/*  71 */     addNetworkMessage((Class)WarlOrbVariables.WorldSavedDataSyncMessageHandler.class, WarlOrbVariables.WorldSavedDataSyncMessage.class, new Side[] { Side.SERVER, Side.CLIENT });
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerSounds(RegistryEvent.Register<SoundEvent> event) {
/*  76 */     for (Map.Entry<ResourceLocation, SoundEvent> sound : sounds.entrySet()) {
/*  77 */       event.getRegistry().register(((SoundEvent)sound.getValue()).setRegistryName(sound.getKey()));
/*     */     }
/*     */   }
/*     */   
/*     */   public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator cg, IChunkProvider cp) {
/*  82 */     this.elements.forEach(element -> element.generateWorld(random, chunkX * 16, chunkZ * 16, world, world.field_73011_w.getDimension(), cg, cp));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBurnTime(ItemStack fuel) {
/*  87 */     for (ModElement element : this.elements) {
/*  88 */       int ret = element.addFuel(fuel);
/*  89 */       if (ret != 0)
/*  90 */         return ret; 
/*     */     } 
/*  92 */     return 0;
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
/*  97 */     if (!event.player.field_70170_p.field_72995_K) {
/*  98 */       WorldSavedData mapdata = WarlOrbVariables.MapVariables.get(event.player.field_70170_p);
/*  99 */       WorldSavedData worlddata = WarlOrbVariables.WorldVariables.get(event.player.field_70170_p);
/* 100 */       if (mapdata != null)
/* 101 */         WarlOrb.PACKET_HANDLER.sendTo(new WarlOrbVariables.WorldSavedDataSyncMessage(0, mapdata), (EntityPlayerMP)event.player); 
/* 102 */       if (worlddata != null)
/* 103 */         WarlOrb.PACKET_HANDLER.sendTo(new WarlOrbVariables.WorldSavedDataSyncMessage(1, worlddata), (EntityPlayerMP)event.player); 
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPlayerChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
/* 109 */     if (!event.player.field_70170_p.field_72995_K) {
/* 110 */       WorldSavedData worlddata = WarlOrbVariables.WorldVariables.get(event.player.field_70170_p);
/* 111 */       if (worlddata != null)
/* 112 */         WarlOrb.PACKET_HANDLER.sendTo(new WarlOrbVariables.WorldSavedDataSyncMessage(1, worlddata), (EntityPlayerMP)event.player); 
/*     */     } 
/*     */   } public ElementsWarlOrb() {
/* 115 */     this.messageID = 0;
/*     */   } @Retention(RetentionPolicy.RUNTIME)
/*     */   public static @interface Tag {} public <T extends net.minecraftforge.fml.common.network.simpleimpl.IMessage, V extends net.minecraftforge.fml.common.network.simpleimpl.IMessage> void addNetworkMessage(Class<? extends IMessageHandler<T, V>> handler, Class<T> messageClass, Side... sides) {
/* 118 */     for (Side side : sides)
/* 119 */       WarlOrb.PACKET_HANDLER.registerMessage(handler, messageClass, this.messageID, side); 
/* 120 */     this.messageID++;
/*     */   }
/*     */   
/*     */   public static class GuiHandler implements IGuiHandler {
/*     */     public Object getServerGuiElement(int id, EntityPlayer player, World world, int x, int y, int z) {
/* 125 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getClientGuiElement(int id, EntityPlayer player, World world, int x, int y, int z) {
/* 130 */       return null;
/*     */     } }
/*     */   
/*     */   public List<ModElement> getElements() {
/* 134 */     return this.elements;
/*     */   }
/*     */   
/*     */   public List<Supplier<Block>> getBlocks() {
/* 138 */     return this.blocks;
/*     */   }
/*     */   
/*     */   public List<Supplier<Item>> getItems() {
/* 142 */     return this.items;
/*     */   }
/*     */   
/*     */   public List<Supplier<Biome>> getBiomes() {
/* 146 */     return this.biomes;
/*     */   }
/*     */   
/*     */   public List<Supplier<EntityEntry>> getEntities() {
/* 150 */     return this.entities;
/*     */   }
/*     */   
/*     */   public List<Supplier<Potion>> getPotions() {
/* 154 */     return this.potions;
/*     */   }
/*     */   
/*     */   public static class ModElement
/*     */     implements Comparable<ModElement> {
/*     */     protected final ElementsWarlOrb elements;
/*     */     protected final int sortid;
/*     */     
/*     */     public ModElement(ElementsWarlOrb elements, int sortid) {
/* 163 */       this.elements = elements;
/* 164 */       this.sortid = sortid;
/*     */     }
/*     */ 
/*     */     
/*     */     public void initElements() {}
/*     */ 
/*     */     
/*     */     public void init(FMLInitializationEvent event) {}
/*     */ 
/*     */     
/*     */     public void preInit(FMLPreInitializationEvent event) {}
/*     */ 
/*     */     
/*     */     public void generateWorld(Random random, int posX, int posZ, World world, int dimID, IChunkGenerator cg, IChunkProvider cp) {}
/*     */ 
/*     */     
/*     */     public void serverLoad(FMLServerStartingEvent event) {}
/*     */ 
/*     */     
/*     */     public void registerModels(ModelRegistryEvent event) {}
/*     */     
/*     */     public int addFuel(ItemStack fuel) {
/* 186 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(ModElement other) {
/* 191 */       return this.sortid - other.sortid;
/*     */     }
/*     */     
/*     */     @Retention(RetentionPolicy.RUNTIME)
/*     */     public static @interface Tag {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Jay.DESKTOP-FPHD60C\AppData\Roaming\.minecraft\mods\Warlord.jar!\net\mcreator\warlorb\ElementsWarlOrb.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */