package net.mcreator.warlorb;

import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;

public class ServerProxyWarlOrb implements IProxyWarlOrb {
  public void preInit(FMLPreInitializationEvent event) {}
  
  public void init(FMLInitializationEvent event) {}
  
  public void postInit(FMLPostInitializationEvent event) {}
  
  public void serverLoad(FMLServerStartingEvent event) {}
}


/* Location:              C:\Users\Jay.DESKTOP-FPHD60C\AppData\Roaming\.minecraft\mods\Warlord.jar!\net\mcreator\warlorb\ServerProxyWarlOrb.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */