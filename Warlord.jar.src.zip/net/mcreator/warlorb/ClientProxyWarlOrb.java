/*    */ package net.mcreator.warlorb;
/*    */ 
/*    */ import net.minecraftforge.client.model.obj.OBJLoader;
/*    */ import net.minecraftforge.fml.common.event.FMLInitializationEvent;
/*    */ import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
/*    */ import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
/*    */ import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
/*    */ 
/*    */ 
/*    */ public class ClientProxyWarlOrb
/*    */   implements IProxyWarlOrb
/*    */ {
/*    */   public void init(FMLInitializationEvent event) {}
/*    */   
/*    */   public void preInit(FMLPreInitializationEvent event) {
/* 16 */     OBJLoader.INSTANCE.addDomain("warlorb");
/*    */   }
/*    */   
/*    */   public void postInit(FMLPostInitializationEvent event) {}
/*    */   
/*    */   public void serverLoad(FMLServerStartingEvent event) {}
/*    */ }


/* Location:              C:\Users\Jay.DESKTOP-FPHD60C\AppData\Roaming\.minecraft\mods\Warlord.jar!\net\mcreator\warlorb\ClientProxyWarlOrb.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */