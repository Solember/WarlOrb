/*    */ package net.mcreator.warlorb.procedure;
/*    */ import net.mcreator.warlorb.ElementsWarlOrb;
/*    */ import net.mcreator.warlorb.ElementsWarlOrb.ModElement.Tag;
/*    */ 
/*    */ @Tag
/*    */ public class ProcedureWarlOrbMobIsHitWithItem extends ElementsWarlOrb.ModElement {
/*    */   public ProcedureWarlOrbMobIsHitWithItem(ElementsWarlOrb instance) {
/*  8 */     super(instance, 1);
/*    */   }
/*    */   
/*    */   public static void executeProcedure(HashMap<String, Object> dependencies) {
/* 12 */     System.out.println("You're an angry one, aren't you?");
/*    */   }
/*    */ }


/* Location:              C:\Users\Jay.DESKTOP-FPHD60C\AppData\Roaming\.minecraft\mods\Warlord.jar!\net\mcreator\warlorb\procedure\ProcedureWarlOrbMobIsHitWithItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */