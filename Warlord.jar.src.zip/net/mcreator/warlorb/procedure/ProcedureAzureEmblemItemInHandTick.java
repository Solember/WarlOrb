/*    */ package net.mcreator.warlorb.procedure;
/*    */ import java.util.HashMap;
/*    */ import net.mcreator.warlorb.ElementsWarlOrb;
/*    */ import net.mcreator.warlorb.ElementsWarlOrb.ModElement.Tag;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ @Tag
/*    */ public class ProcedureAzureEmblemItemInHandTick extends ElementsWarlOrb.ModElement {
/*    */   public ProcedureAzureEmblemItemInHandTick(ElementsWarlOrb instance) {
/* 10 */     super(instance, 18);
/*    */   }
/*    */   
/*    */   public static void executeProcedure(HashMap<String, Object> dependencies) {
/* 14 */     if (dependencies.get("entity") == null) {
/* 15 */       System.err.println("Failed to load dependency entity for procedure AzureEmblemItemInHandTick!");
/*    */       return;
/*    */     } 
/* 18 */     Entity entity = (Entity)dependencies.get("entity");
/* 19 */     entity.field_70143_R = 0.0F;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jay.DESKTOP-FPHD60C\AppData\Roaming\.minecraft\mods\Warlord.jar!\net\mcreator\warlorb\procedure\ProcedureAzureEmblemItemInHandTick.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */