/*    */ package net.mcreator.warlorb.procedure;
/*    */ import java.util.HashMap;
/*    */ import net.mcreator.warlorb.ElementsWarlOrb;
/*    */ import net.mcreator.warlorb.ElementsWarlOrb.ModElement.Tag;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.init.MobEffects;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ 
/*    */ @Tag
/*    */ public class ProcedureOchreEmblemItemInHandTick extends ElementsWarlOrb.ModElement {
/*    */   public ProcedureOchreEmblemItemInHandTick(ElementsWarlOrb instance) {
/* 13 */     super(instance, 20);
/*    */   }
/*    */   
/*    */   public static void executeProcedure(HashMap<String, Object> dependencies) {
/* 17 */     if (dependencies.get("entity") == null) {
/* 18 */       System.err.println("Failed to load dependency entity for procedure OchreEmblemItemInHandTick!");
/*    */       return;
/*    */     } 
/* 21 */     Entity entity = (Entity)dependencies.get("entity");
/* 22 */     if (entity instanceof EntityLivingBase)
/* 23 */       ((EntityLivingBase)entity).func_70690_d(new PotionEffect(MobEffects.field_76430_j, 60, 2, false, false)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Jay.DESKTOP-FPHD60C\AppData\Roaming\.minecraft\mods\Warlord.jar!\net\mcreator\warlorb\procedure\ProcedureOchreEmblemItemInHandTick.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */