/*    */ package net.mcreator.warlorb.creativetab;
/*    */ 
/*    */ import net.mcreator.warlorb.ElementsWarlOrb;
/*    */ import net.mcreator.warlorb.ElementsWarlOrb.ModElement.Tag;
/*    */ import net.mcreator.warlorb.item.ItemWarlOrb;
/*    */ import net.minecraft.creativetab.CreativeTabs;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ @Tag
/*    */ public class TabWarlord extends ElementsWarlOrb.ModElement {
/*    */   public static CreativeTabs tab;
/*    */   
/*    */   public TabWarlord(ElementsWarlOrb instance) {
/* 16 */     super(instance, 4);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initElements() {
/* 32 */     tab = (new CreativeTabs("tabwarlord") { @SideOnly(Side.CLIENT) public ItemStack func_78016_d() { return new ItemStack(ItemWarlOrb.block, 1); } @SideOnly(Side.CLIENT) public boolean hasSearchBar() { return true; } }).func_78025_a("item_search.png");
/*    */   }
/*    */ }


/* Location:              C:\Users\Jay.DESKTOP-FPHD60C\AppData\Roaming\.minecraft\mods\Warlord.jar!\net\mcreator\warlorb\creativetab\TabWarlord.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */